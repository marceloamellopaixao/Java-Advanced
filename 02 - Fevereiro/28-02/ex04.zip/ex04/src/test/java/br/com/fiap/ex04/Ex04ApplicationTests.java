package br.com.fiap.ex04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
